<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Requisicao extends Model
{
    use HasFactory;
    protected $primaryKey="id_requisicao";
    protected $table="requisicoes";

    public function requisicao() {
return $this->hasMany('App\Models\Requisicao', 'id_material');
}
}
