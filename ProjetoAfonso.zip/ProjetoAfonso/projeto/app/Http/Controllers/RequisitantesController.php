<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Requisitante;
class RequisitantesController extends Controller
{
    //
           public function index(){

	$requisitante= Requisitante::paginate(4);

	return view ('requisitantes.index', ['requisitantes'=>$requisitante]);
}
public function show (Request $request){
	$idRequisitante=$request->id;

	$requisitante=Requisitante::where('id_requisitante',$idRequisitante)->first();
	
	return view ('requisitantes.show',['requisitante'=>$requisitante]);
}
}
