<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Material;
class MateriaisController extends Controller
{
   public function index(){

	$material= Material::paginate(4);

	return view ('materiais.index', ['materiais'=>$material]);
}
public function show (Request $request){
	$idMaterial=$request->id;


	$material=Material::where('id_material',$idMaterial)->first();
	
	return view ('materiais.show',['material'=>$material]);
}
}
